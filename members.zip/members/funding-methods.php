<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Funding Methods | TEI</title>
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
		<link href="login/loginstyle.css" rel="stylesheet" type="text/css">
	</head>
	<body>
	        
		<div class="login">
    <h1>Funding Methods</h1>
    <p align="center"><a href="http://www.theeduinitiative.com/.com">Go to Home Page</a></P>
    <form>
<p><B>Easy Paisa</B>&nbsp;&nbsp;0333-7701800</p>
<p><B>MCB Bank</B>&nbsp;&nbsp;1373893121009047</p>
<p><B>Account Title</B>&nbsp;&nbsp; Aown Muhammad Shah</p>
<p align="center">Please send your first month funding and WhatsApp transaction receipt along with your CNIC for account activation 0092-345-7111102</p>
  <input type="submit" value="Funding Methods">
    </form>
</div>
	</body>
</html>
