
	<?php

	$host ="localhost";
	$uname = "root";
	$pwd = 'shahg';
	$db_name = "schoolfeesys";

        ?>